create table if not exists public.shared_dishes (
  id text primary key default gen_random_uuid()::text,
  title text not null check (length(btrim(title)) > 0),
  normalized_title text generated always as (lower(btrim(title))) stored unique,
  category text,
  protein_type text not null check (
    protein_type in (
      'mince', 'chicken', 'sausage', 'meat', 'pork', 'fish', 'stew',
      'soup', 'cheese', 'egg', 'mushroom', 'pulled', 'legumes', 'other'
    )
  ),
  preferred_days text not null check (preferred_days in ('weekdays', 'weekends', 'both')),
  carb_type text check (
    carb_type is null or carb_type in (
      'pasta', 'rice', 'potatoes', 'salad', 'bulgur_couscous', 'noodles', 'bread', 'other'
    )
  ),
  is_quick boolean not null default false,
  is_slow_cooked boolean not null default false,
  created_by uuid default auth.uid() references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.user_dish_statuses (
  user_id uuid not null references auth.users(id) on delete cascade,
  dish_id text not null,
  status text not null check (status in ('yes', 'no', 'maybe')),
  updated_at timestamptz not null default now(),
  primary key (user_id, dish_id)
);

alter table public.shared_dishes enable row level security;
alter table public.user_dish_statuses enable row level security;

grant select on public.shared_dishes to anon, authenticated;
grant insert on public.shared_dishes to authenticated;
grant select, insert, update, delete on public.user_dish_statuses to authenticated;

drop policy if exists "Anyone can read shared dishes" on public.shared_dishes;
create policy "Anyone can read shared dishes"
  on public.shared_dishes for select
  using (true);

drop policy if exists "Authenticated users can add shared dishes" on public.shared_dishes;
create policy "Authenticated users can add shared dishes"
  on public.shared_dishes for insert to authenticated
  with check (created_by = (select auth.uid()));

drop policy if exists "Users can read their own dish statuses" on public.user_dish_statuses;
create policy "Users can read their own dish statuses"
  on public.user_dish_statuses for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "Users can add their own dish statuses" on public.user_dish_statuses;
create policy "Users can add their own dish statuses"
  on public.user_dish_statuses for insert to authenticated
  with check (user_id = (select auth.uid()));

drop policy if exists "Users can update their own dish statuses" on public.user_dish_statuses;
create policy "Users can update their own dish statuses"
  on public.user_dish_statuses for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

drop policy if exists "Users can delete their own dish statuses" on public.user_dish_statuses;
create policy "Users can delete their own dish statuses"
  on public.user_dish_statuses for delete to authenticated
  using (user_id = (select auth.uid()));
